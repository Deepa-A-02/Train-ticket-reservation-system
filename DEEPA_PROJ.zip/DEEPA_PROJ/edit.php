<?php  
session_start();
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
  $loggedin= true;
}
?>
<!doctype html>
<html lang="en" >
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" integrity="sha384-WJUUqfoMmnfkBLne5uxXj+na/c7sesSJ32gI7GfCk4zO4GthUKhSEGyvQ839BC51" crossorigin="anonymous">
  <style>
    .box{
      width: 900px;
      height: 800px;
      margin: 4px 290px;
      border: 2px solid black;
    }
    .hd{
      color: gold;
    }
  </style>
    <title>Form</title>
  </head>
  <body>
  <!-- <nav class="navbar navbar-expand-lg navbar-dark bg-dark"> -->
  <!-- <nav class="navbar bg-body-tertiary "> -->
  <nav class="navbar bg-dark" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand">Train Ticket</a>
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
  </div>
</nav>
<div class="text-center">
  <h1 class="hd">Ticket Reserved Information</h1>
  <div class="button">
  <a href="http://localhost/DEEPA_PROJ/delete.php"><button type="button"  class="btn btn-danger btn">DELETE</button></a>
  <!-- <a href="DEEPA_PROJ\delete.php">Delete form</a> -->
<a href="http://localhost/DEEPA_PROJ/update.php"><button type="button" class="btn btn-primary btn">Update</button></a>
</div>
  <div class="box">
 
    <div class="details">
<h3><?php echo' FIRST NAME   :     '."      ".$_SESSION['fname']."   "          ;?></h3>

  </div>
    <div class="details">
<h3><?php echo' FIRST NAME    :     '."".$_SESSION['lname'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' LAST NAME    :     '."".$_SESSION['age'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' GENDER    :     '."".$_SESSION['gender'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' MOBILE    :     '."".$_SESSION['mob'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' DATE-OF-BIRTH    :     '."".$_SESSION['dob'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' DATE-OF-BOOKING    :     '."".$_SESSION['dateofbook'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' NUMBER-OF-PERSON    :     '."".$_SESSION['noofperson'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' FROM    :     '."".$_SESSION['from'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' TO    :     '."".$_SESSION['to'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' TIME    :     '."".$_SESSION['time'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' SEAT    :     '."".$_SESSION['seat'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' TRAIN NAME    :     '."".$_SESSION['Tname'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' RESERVATION QUOTA    :     '."".$_SESSION['Quota'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' ADDRESS    :     '."".$_SESSION['Address'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' PINCODE    :     '."".$_SESSION['Pincode'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' EMAIL    :     '."".$_SESSION['email'];?></h3>
  </div>
    <div class="details">
<h3><?php echo' PASSWORD :     '."".$_SESSION['password'];?></h3>
  </div>
  </div>

</div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    -->
  </body>
</html>