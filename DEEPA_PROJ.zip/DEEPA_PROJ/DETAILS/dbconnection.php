<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "online_railway";

$conn = mysqli_connect($server,$username,$password,$database);
if(!$conn){
//     echo "successfull";
// }
// else{
    die ("ERROR". mysqli_connect_error());
}
?>