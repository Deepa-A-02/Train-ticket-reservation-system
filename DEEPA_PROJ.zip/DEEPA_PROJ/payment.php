<!doctype html>
<html lang="en" >
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" integrity="sha384-WJUUqfoMmnfkBLne5uxXj+na/c7sesSJ32gI7GfCk4zO4GthUKhSEGyvQ839BC51" crossorigin="anonymous">
     <style>
      .img1{
            width: 100%;
            position: absolute;
            /* z-index: -1;
            opcity: -0.4; */
        }
      .container{
        position: fixed;
        margin: 100px 450px;
        /* margin-right:auto;
        margin-left:auto; */
        width: 600px;
        height: 350px;
        border: 4px solid grey;
        border-radius:10px;
      }
      h4{
        color:sky-blue;
      }
      h1,h2{
        color:white;
      }
     </style>
    <title>welcome</title>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- <nav class="navbar bg-body-tertiary "> -->
  <div class="container-fluid">
    <a class="navbar-brand" href="http://localhost/DEEPA_PROJ/welcome.php/"><button type="button" class="btn btn-primary">Welcome</button>
</a>
<div class="form">
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-danger" type="submit">Search</button>
    </form>
  </div>
</nav>

<!-- <img src="https://source.unsplash.com/1600x725/?train" class="img-fluid" alt="..."> -->
<!-- <img src="https://source.unsplash.com/1600x725/?train" alt="train" class="img1"> -->

<!-- PROGRAM START HERE  -->
<div class="container">
<form action="\DEEPA_PROJ\payment.php" method="post">
  <b><h1 class="text-center mt-4 mb-7">Payment Methods</h1></b>
<div class="search_select_box mt-2">
    <select class="w-100" data-live-search="true">
        <option>Payment</option>
        <option>gpay</option>
        <option>phonepay</option>
        <option>paytm</option>
    
    </select>
</div>
<div class="mt-3">
  
    <label for="exampleInputPassword1" class="form-label">Phone Number</label>
    <input type="phonenumber" class="form-control" placeholder="Enter Your Phone number" name="password" id="password">
  </div>
<div class="mt-3">
    <label for="exampleInputPassword1" class="form-label">Number Of Passenger</label>
    <input type="number" class="form-control"  name="number" id="number">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
  
</form>

<?php
$showError=false;
// $number=0;
if($_SERVER["REQUEST_METHOD"]=="POST"){
  include 'DETAILS\dbconnection.php';
    $number =$_POST["number"];
    // var_dump($number);
    
    if($number<=0){
       $showError=true;
    }
    else{
        echo 'Your Payment is: '.$number*200,'Rs';
    }
} 
?>
<!-- <?php
if($showError){
echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
}
?>
</div>
  



<a href="http://localhost/DEEPA_PROJ/edit.php">click her to download application</a>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    -->
  </body>
</html>