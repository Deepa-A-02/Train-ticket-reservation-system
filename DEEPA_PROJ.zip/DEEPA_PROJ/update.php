<?php
// session_start();
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'DETAILS\dbconnection.php';
   $fname=$_POST["fname"];
   $lname=$_POST["lname"];
    $age = $_POST["age"];
    $gender=$_POST["gender"];
    $mob = $_POST["mob"];
    $dob=$_POST["dob"];
    $dateofbook = $_POST["dateofbook"];
    $noofperson = $_POST["noofperson"];
    $from = $_POST["from"];
    $to = $_POST["to"];
    $time = $_POST["time"];
    $seat = $_POST["seat"];
    $Tname = $_POST["Tname"];
    $Quota = $_POST["Quota"];
    $Address = $_POST["Address"];
    $Pincode = $_POST["Pincode"];


    $email = $_POST["email"];
    $password = $_POST["password"];

    


    $existSql = "SELECT  * FROM `online_railway` WHERE email='$email' AND password= 'password'";
    $result = mysqli_query($conn, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows < 0){
        // $exists = true;
        $showError = " Already Exists";
    }
    else{
  
          //  $sql = "UPDATE   `online_railway` SET (`Fname`, `Lname`, `Age`, `Gender`, `mobileno`, `DOB`, `Address`, `Pincode`, `dateofbook`, `No_Persons`, `from_place`, `to_place`, `timings`, `class`, `train_name`, `reser_quota`, `email`, `password`, `dt`) VALUES ('$fname', '$lname', '$age', '$gender', '$mob', '$dob', '$Address', '$Pincode', '$dateofbook', '$noofperson', '$from', '$to', '$time', '$seat', '$Tname', '$Quota', '$email', '$password', current_timestamp())";
          $sql="UPDATE `online_railway` SET `Fname`='$fname', `Lname`='$lname', `Age`='$age', `Gender`='$gender', `mobileno`='$mob', `DOB`='$dob', `Address`='$Address', `Pincode`='$Pincode', `dateofbook`='$dateofbook', `No_Persons`='$noofperson', `from_place`='$from', `to_place`='$to', `timings`='$time', `class`='$seat', `train_name`='$Tname', `reser_quota`='$Quota'
          WHERE `email`='$email' AND `password`='$password'";
            $result= mysqli_query($conn, $sql);
     
            if($result){
                echo 'Updated Successfully';
            }
            else{
                $err= mysli_error($conn);
                echo "not updated successfully due to this error";
            }
    }
}
    
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
   <style>
    .search_select_box{
      width:50%;
      padding: 4px;
    }
    
   </style>
    <title>SignUp</title>
  </head>
  <body> 

    <?php require 'DETAILS\nav.php'?>
    <?php
    if($showAlert){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your account is now created and you can login
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div> ';
    }
    ?>

    <div class="container my-3">
     <h1 class="text-center">Signup To Book Ur Ticket</h1>
     <form action="\DEEPA_PROJ\update.php" method="post">
         
     <div class="row my-3">
  <div class="col">
    <input type="text" class="form-control" placeholder="First name" name="fname" id="fname" aria-label="First name">
  </div>
  <div class="col">
    <input type="text" class="form-control" placeholder="Last name" name="lname" id="lname" aria-label="Last name">
  </div>
</div>
   
<div class="row my-3">
  <div class="col">
    <input type="text" class="form-control" placeholder="Age" name="age" id="age"  aria-label="age">
  </div>
  <div class="col">
    <input type="text" class="form-control" placeholder="Gender" name="gender" id="gender" aria-label="">
  </div>
</div>

<div class="row my-3">
  <div class="col">
    <input type="text" class="form-control" placeholder="Mobile no" name="mob" id="mob" aria-label="Mobile no">
  </div>
  <div class="col">
    <input type="text" class="form-control" placeholder="Date of Birth" name="dob" id="dob" aria-label="Date of Birth">
  </div>
</div>
<div class="row my-3">
  <div class="col">
    <input type="text" class="form-control" placeholder="Address" name="Address" id="Address" aria-label="First name">
  </div>
  <div class="col">
    <input type="text" class="form-control" placeholder="Pincode" name="Pincode" id="Pincode" aria-label="Last name">
  </div>
</div>
<div class="row my-3">
  <div class="col">
    <input type="text" class="form-control" placeholder="Date of Booking" name="dateofbook" id="dateofbook" aria-label="age">
  </div>
  <div class="col">
    <input type="text" class="form-control" placeholder="No. of Passengers" name="noofperson" id="noofperson" aria-label="">
  </div>
</div>

<div class="row my-3">
  <div class="search_select_box mt-2 ">
    <select class="w-100" name="from" id="from" data-live-search="true">
        <option>From</option>
        <option>Banglore</option>
        <option>Mysore</option>
        <option>Chikmanglore</option>
        <option>Davangere</option>
        <option>Mandya</option>
        <option>Udupi</option>
        <option>Bidar</option>
        <option>Haasan</option>
    
    </select>
  </div>

 <div class="search_select_box mt-2">
    <select class="w-100" name="to" id="to" data-live-search="true">
        <option>To</option>
        <option>Mandya</option>
        <option>Davangere</option>
        <option>Banglore</option>
        <option>Haasan</option>
        <option>Udupi</option>
        <option>Mysore</option>
        <option>Chikmanglore</option>
        <option>Bidar</option>
        
    
    </select>
</div> 
</div>


<div class="row my-3">
<div class="search_select_box mt-2 ">
    <select class="w-100" name="time" id="time" data-live-search="true">
        <option>Timings</option>
        <option>6AM -- 8AM</option>
        <option>7AM -- 9AM</option>
        <option>10AM -- 12PM</option>
        <option>11AM -- 1PM</option>
        <option>2PM -- 4PM</option>
        <option>4PM -- 6PM</option>
        <option>6PM -- 8PM</option>
        <option>8PM -- 10PM</option>

        
    
    </select>
    
</div>
<div class="search_select_box mt-2 ">
    <select class="w-100" name="seat" id="seat" data-live-search="true">
        <option>Class</option>
        <option>Normal</option>
        <option>Sleeper</option>
      

        
    
    </select>
    
</div>
</div>
<div class="row my-3">
<div class="search_select_box mt-2 ">
    <select class="w-100" name="Tname" id="Tname" data-live-search="true">
        <option>Train Name</option>
        <option>HAMPI EXPRESS(16238)</option>
        <option>BANGLORE RJDHNI(45638)</option>
        <option>KTK EXPRESS(17592)</option>
        <option>GANGA EXPRESS(89473)</option>
        <option>RANIKHET EXPRESS(42871)</option>
        <option>SHAHEED EXPRESS(93581)</option>
        <option>BANGLORE EXPRESS(63749)</option>
        <option>KALINDI RJDHNI(88531) </option>

        
    
    </select>
    
</div>
<div class="search_select_box mt-2 ">
    <select class="w-100" name="Quota" id="Quota" data-live-search="true">
        <option>Reservation Quota</option>
        <option>General</option>
        <option>Tatkal</option>
        <option>Ladies</option>
        <option>Emergency</option>
        <option>Senior citizen</option>
      

        
    
    </select>
    
</div>
</div>



  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control"  name="email" id="email">
    </div>
  </div>

  <div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="password" id="password">
    </div>
  </div>


  <button type="submit" class="btn btn-primary">Sign in</button>

        
      

     </form>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>