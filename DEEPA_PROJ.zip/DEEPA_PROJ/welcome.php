<!doctype html>
<html lang="en" >
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" integrity="sha384-WJUUqfoMmnfkBLne5uxXj+na/c7sesSJ32gI7GfCk4zO4GthUKhSEGyvQ839BC51" crossorigin="anonymous">
     <style>
      .img1{
            width: 100%;
            position: absolute;
            /* z-index: -1;
            opcity: -0.4; */
        }
      .container{
        position: fixed;
        margin: 100px 450px;
        /* margin-right:auto;
        margin-left:auto; */
        width: 600px;
        height: 300px;
        border: 4px solid grey;
        border-radius:10px;
      }
      h4{
        color:sky-blue;
      }
      h1,h2{
        color:white;
      }
     </style>
    <title>welcome</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- <nav class="navbar bg-body-tertiary "> -->
  <div class="container-fluid">
    <a class="navbar-brand" href="http://localhost/DEEPA_PROJ/welcome.php/"><button type="button" class="btn btn-primary">Welcome</button>
</a>
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-danger" type="submit">Search</button>
    </form>
  </div>
</nav>
<!-- <img src="https://source.unsplash.com/1600x725/?train" class="img-fluid" alt="..."> -->
<img src="https://source.unsplash.com/1600x725/?train" alt="train" class="img1">
<div class="container">
  <b><h1 class="text-center mt-4 mb-7">Welcome To Indian Railway!</h1></b>
  <b><h2 class="text-center mt-4">Have A Safe Journey With Us </h2></b>
  <a href="http://localhost/DEEPA_PROJ/signup.php/"><h4 class="text-center mt-4">Please Signup Before Booking</h4></a>



</div>
  



    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    -->
  </body>
</html>